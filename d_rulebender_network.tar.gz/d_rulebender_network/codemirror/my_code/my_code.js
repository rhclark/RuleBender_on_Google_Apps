

CodeMirror.defineMode("my_mode", function() {
  return {
    token: function(stream,state) {
       if (stream.match('#') ) {
          stream.skipToEnd();
          return "style_bngl_brown";
       }
       else if (stream.match("begin parameters") ) { return "style_bngl_red"; }
       else if (stream.match("end parameters") )   { return "style_bngl_red"; }
       else if (stream.match("begin model") ) { return "style_bngl_blue"; }
       else if (stream.match("end model") )   { return "style_bngl_blue"; }
       else {
          stream.next();
          return null;
       }
    }
  };
});

