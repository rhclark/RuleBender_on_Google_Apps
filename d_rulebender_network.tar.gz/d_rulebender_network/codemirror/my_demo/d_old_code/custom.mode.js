
var _glob_keywords = [ [ "key1", "bng_species" ],
                       [ "key2", "keyword2" ]
                     ] ;

var cm_custom_check_stream_fn = function( stream )
{
    for( var _i = 0 ; _i < _glob_keywords.length ; _i++ )
    {
        if ( stream.match( _glob_keywords[_i][0] ) ) return _glob_keywords[_i][1] ;
    }
    return "" ;
}

CodeMirror.defineMode("custom.mode", function()
{
    return {
    token: function(stream,state)
            {  
                var _ret = cm_custom_check_stream_fn( stream ) ;
                window.alert("_ret = " + _ret);
                if ( _ret.length > 0 ) return _ret ;
                else { stream.next(); return null; }
            }
           };
});
