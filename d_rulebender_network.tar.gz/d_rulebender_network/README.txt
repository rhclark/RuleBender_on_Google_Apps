
    This tar file contains the HTML file that Rob Clark used in his
"Hitchhikers Guide to the RuleBender Network" talk.

    The HTML file is called guide.html, and it can be viewed in any
browser.  This tar file is large, because it includes a complete 
installation of   CodeMirror  With this installation, the various
tool samples can be viewed simply by clicking on the links in the
presentation.

